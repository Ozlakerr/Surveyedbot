document.addEventListener('DOMContentLoaded', () => {
  const urlInput = document.getElementById('surveyUrl');
  const startBtn = document.getElementById('startBtn');
  const loadingDiv = document.getElementById('loading');
  const resultDiv = document.getElementById('result');

  startBtn.addEventListener('click', async () => {
    const url = urlInput.value.trim();
    if (!url) {
      alert('Please enter a survey URL');
      return;
    }

    try { new URL(url); } catch {
      alert('Please enter a valid URL (including https://)');
      return;
    }

    loadingDiv.style.display = 'flex';
    resultDiv.style.display = 'none';
    startBtn.disabled = true;

    try {
      const response = await fetch('/api/complete-survey', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });
      const data = await response.json();

      if (response.ok && data.success) {
        resultDiv.innerHTML = `<strong>✅ Survey completed!</strong><br><br>${data.result}`;
        resultDiv.style.display = 'block';
      } else {
        throw new Error(data.error || 'Unknown error');
      }
    } catch (err) {
      alert('Error: ' + err.message);
    } finally {
      loadingDiv.style.display = 'none';
      startBtn.disabled = false;
    }
  });

  urlInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') startBtn.click();
  });
});